function myFunction() {
  var str = document.getElementById("demo").innerHTML; 
  var txt = str.replace("Top 12 Shows","0-9");
  document.getElementById("demo").innerHTML = txt;
}

function myFunctionA() {
  var str = document.getElementById("demo").innerHTML; 
  var txt = str.replace("Top 12 Shows","A");
  document.getElementById("demo").innerHTML = txt;
}

/*
function myFunctionB() {
  var str = document.getElementById("demo").innerHTML; 
  var txt = str.replace("Top 12 Shows","B");
  document.getElementById("demo").innerHTML = txt;
}
function myFunctionC() {
  var str = document.getElementById("demo").innerHTML; 
  var txt = str.replace("Top 12 Shows","C");
  document.getElementById("demo").innerHTML = txt;
}
function myFunctionD() {
  var str = document.getElementById("demo").innerHTML; 
  var txt = str.replace("Top 12 Shows","D");
  document.getElementById("demo").innerHTML = txt;
}
function myFunctionE() {
  var str = document.getElementById("demo").innerHTML; 
  var txt = str.replace("Top 12 Shows","E");
  document.getElementById("demo").innerHTML = txt;
}
function myFunctionF() {
  var str = document.getElementById("demo").innerHTML; 
  var txt = str.replace("Top 12 Shows","F");
  document.getElementById("demo").innerHTML = txt;
}
function myFunctionG() {
  var str = document.getElementById("demo").innerHTML; 
  var txt = str.replace("Top 12 Shows","G");
  document.getElementById("demo").innerHTML = txt;
}
function myFunctionH() {
  var str = document.getElementById("demo").innerHTML; 
  var txt = str.replace("Top 12 Shows","H");
  document.getElementById("demo").innerHTML = txt;
}
function myFunctionI() {
  var str = document.getElementById("demo").innerHTML; 
  var txt = str.replace("Top 12 Shows","I");
  document.getElementById("demo").innerHTML = txt;
}
function myFunctionJ() {
  var str = document.getElementById("demo").innerHTML; 
  var txt = str.replace("Top 12 Shows","J");
  document.getElementById("demo").innerHTML = txt;
}
function myFunctionK() {
  var str = document.getElementById("demo").innerHTML; 
  var txt = str.replace("Top 12 Shows","K");
  document.getElementById("demo").innerHTML = txt;
}
function myFunctionL() {
  var str = document.getElementById("demo").innerHTML; 
  var txt = str.replace("Top 12 Shows","L");
  document.getElementById("demo").innerHTML = txt;
}
function myFunctionM() {
  var str = document.getElementById("demo").innerHTML; 
  var txt = str.replace("Top 12 Shows","M");
  document.getElementById("demo").innerHTML = txt;
}
function myFunctionN() {
  var str = document.getElementById("demo").innerHTML; 
  var txt = str.replace("Top 12 Shows","N");
  document.getElementById("demo").innerHTML = txt;
}
function myFunctionO() {
  var str = document.getElementById("demo").innerHTML; 
  var txt = str.replace("Top 12 Shows","O");
  document.getElementById("demo").innerHTML = txt;
}
function myFunctionP() {
  var str = document.getElementById("demo").innerHTML; 
  var txt = str.replace("Top 12 Shows","P");
  document.getElementById("demo").innerHTML = txt;
}
function myFunctionQ() {
  var str = document.getElementById("demo").innerHTML; 
  var txt = str.replace("Top 12 Shows","Q");
  document.getElementById("demo").innerHTML = txt;
}
function myFunctionR() {
  var str = document.getElementById("demo").innerHTML; 
  var txt = str.replace("Top 12 Shows","R");
  document.getElementById("demo").innerHTML = txt;
}
function myFunctionS() {
  var str = document.getElementById("demo").innerHTML; 
  var txt = str.replace("Top 12 Shows","S");
  document.getElementById("demo").innerHTML = txt;
}
function myFunctionT() {
  var str = document.getElementById("demo").innerHTML; 
  var txt = str.replace("Top 12 Shows","T");
  document.getElementById("demo").innerHTML = txt;
}function myFunctionU() {
  var str = document.getElementById("demo").innerHTML; 
  var txt = str.replace("Top 12 Shows","U");
  document.getElementById("demo").innerHTML = txt;
}
function myFunctionV() {
  var str = document.getElementById("demo").innerHTML; 
  var txt = str.replace("Top 12 Shows","V");
  document.getElementById("demo").innerHTML = txt;
}
function myFunctionW() {
  var str = document.getElementById("demo").innerHTML; 
  var txt = str.replace("Top 12 Shows","W");
  document.getElementById("demo").innerHTML = txt;
}
function myFunctionX() {
  var str = document.getElementById("demo").innerHTML; 
  var txt = str.replace("Top 12 Shows","X");
  document.getElementById("demo").innerHTML = txt;
}
function myFunctionY() {
  var str = document.getElementById("demo").innerHTML; 
  var txt = str.replace("Top 12 Shows","Y");
  document.getElementById("demo").innerHTML = txt;
}
function myFunctionZ() {
  var str = document.getElementById("demo").innerHTML; 
  var txt = str.replace("Top 12 Shows","Z");
  document.getElementById("demo").innerHTML = txt;
}
*/