/*

 function validation(){
    var email=["kilinochchi@uki.life","ram727456@gmail.com","k.tharusan@gmail.com",
                "tharusank23@gmail.com","kiribay@gmail.com"];
    var password=["Uki@ch01","Uki@ch02","Uki@ch03","Uki@ch04","Uki@ch05"];

    var Email = document.getElementById('email').value;
    var passWord = document.getElementById('password').value;

    if ((email[0]==Email)&&(password[0]==passWord)){
      swal("Login Successful !", "You clicked the button!", "success");
    }
    else if ((email[1]==Email)&&(password[1]==passWord)){
      swal("Login Successful !", "You clicked the button!", "success");
    }
    else if ((email[2]==Email)&&(password[2]==passWord)){
      swal("Login Successful !", "You clicked the button!", "success");
    }
    else if ((email[3]==Email)&&(password[3]==passWord)){
      swal("Login Successful !", "You clicked the button!", "success");
    }
    else if ((email[4]==Email)&&(password[4]==passWord)){
      swal("Login Successful !", "You clicked the button!", "success");
    }
    else{
        sweetAlert("Oops... Login failed !!", "Email or password is wrong!", "error");
    }

}
*/
 /*
function Aboutme() {
                 
       var Email = document.getElementById('email').value;
        var Password = document.getElementById('password').value;
                                                             
                var html ="User e-mail: "+ Email +"<br><br>"+ "Password: " +Password;
                                                             
                     document.getElementById('result1').innerHTML = html+
                     +swal("Login Successful!", "You clicked the button go to your page!", "success");
                                                            }
                                                             
                                document.getElementById('About').addEventListener('click',Aboutme);

*/


  function Hide()
{
  var Password = document.getElementById('password');
  var passStatus = document.getElementById('pass-status');
 
  if (Password.type == 'password'){
    Password.type='text';
    passStatus.className='fa fa-eye-slash';
    
  }
  else{
    Password.type='password';
    passStatus.className='fa fa-eye';
  }
}

$(document).ready(function(){       
   var scroll_start = 0;
   var startchange = $('#startchange');
   var offset = startchange.offset();
    if (startchange.length){
   $(document).scroll(function() { 
      scroll_start = $(this).scrollTop();
      if(scroll_start > offset.top) {
          $(".navbar-default").css('background-color', '#f0f0f0');
       } else {
          $('.navbar-default').css('background-color', 'transparent');
       }
   });
    }
});



var sys = {
  users: [
      {username: "kilinochchi@uki.life",password: "Uki@ch01"}, 
      {username: "ram727456@gmail.com",password: "Uki@ch02"},
      {username: "k.tharusan@gmail.com",password: "Uki@ch03"},
      {username: "tharusank23@gmail.com",password: "Uki@ch04"},
      {username: "kiribay@gmail.com",password: "Uki@ch05"}
  ],
  addUser: function() {
    var email = document.getElementById('email').value
    var password = document.getElementById('password').value
    
    // This will check if object with same username and password exists in array
    var check = this.users.some(function(e) {
      return e.username == email && e.password == password
    })
    
    document.getElementById('').innerHTML =check ? swal("Login Successful !", "You clicked the button go to your page!", "success") :
    +sweetAlert("Login Unsuccessful !!", "Email or password is wrong!", "error");
  }
};

// You need to use bind here so that context of this in your method is that object and not element on which you are calling event listener
document.getElementById("myButton").addEventListener("click", sys.addUser.bind(sys));



 $(document).ready(function(){

      $('#email').focusout(function(){
        email_validate();
      });

      function email_validate() {

        var pattern = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
        var email = $('#email').val();
        
        if(email !== '') {
          if(pattern.test(email)) {
          $('#lbl2').css('color','green');
          $('#email').css('border','2px solid green'); 
          $('#success2').css('display','block');
          $('#error2').css('display','none');
          $('#span3').css('display','none');
          $('#span4').css('display','none');
          $('#warning2').css('display','none');
          }
          else {
          $('#lbl2').css('color','#a94442');
          $('#email').css('border','2px solid #a94442'); 
          $('#error2').css('display','block');
          $('#success2').css('display','none');
          $('#span3').css('display','block');
          $('#span4').css('display','none');
          $('#warning2').css('display','none');
          }
        }
        else {
          $('#span4').css('display','block');
          $('#lbl2').css('color','#a94442');
          $('#email').css('border','2px solid #a94442'); 
          $('#error2').css('display','none');
          $('#success2').css('display','none');
          $('#warning2').css('display','block');
          $('#span3').css('display','none');
        }
      }
    });